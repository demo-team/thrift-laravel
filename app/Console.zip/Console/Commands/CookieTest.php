<?php
/**
 * Created by PhpStorm.
 * User: nilyang
 * Date: 15/6/23
 * Time: 16:36
 */
namespace App\Console\Commands;

use Illuminate\Console\Command;
use http\Client, http\Client\Request, http\Cookie;
use http\QueryString;
class CookieTest extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'cookietest';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '测试ios cookie 登录';

    public function handle()
    {
        #1.cookie获取测试

        /**
         * @var \HttpQueryString $params
         */
        $params = new QueryString;
        $params["foo"] = "bar";
        $params["bar"] = "foo";

        /**
         * @var \HttpRequest $http
         */
        $request = new Request("GET", "http://api.ptage.com:8090/juxiang_poc/user/me");
        $request->getBody()->append($params);
        $request->setContentType("text/json");

        $cookie_str = 'frontend=hjbjmjfqmj2ht653ce9korfv00; expires=Tue, 23-Jun-2015 11:57:04 GMT; Max-Age=3600; path=/; domain=.ptage.com; HttpOnly';
        $cookie_obj = new Cookie($cookie_str);
        $client = new Client;
        $client->setCookies($cookie_obj->toArray());
        $client->enqueue($request);
        $client->send();

        /** @var \HttpResponse $response */
        $response = $client->getResponse($request);
        printf("Sent:\n%s\n\n", $response->getParentMessage());
        printf("%s returned '%s'\n%s\n",
            $response->getTransferInfo("effective_url"),
            $response->getInfo(),
            $response->getBody()
        );
        print_r($response);
        $cookie_str= $response->getHeader('Set-Cookie');
        echo($cookie_str);

        $cookie_obj = new Cookie($cookie_str);
        $cookie_arr = $cookie_obj->toArray();
        print_r($cookie_arr);


        #2.登陆测试
        print "\n==============请求login=====================\n";


        $params = [
            'mock'=>1
        ];
        $request_login = new Request("GET", "http://api.ptage.com:8090/juxiang_poc/user/login");
        $request_login->getBody()->append($params);
        $request_login->setContentType("text/json");

        $client = new Client;
        $client->setCookies($cookie_arr);
        $client->enqueue($request_login);
        $client->send();
        /** @var \HttpResponse $response */
        $response = $client->getResponse($request_login);
        printf("Sent:\n%s\n\n", $response->getParentMessage());
        printf("%s returned '%s'\n%s\n",
            $response->getTransferInfo("effective_url"),
            $response->getInfo(),
            $response->getBody()
        );
        $cookie_str= $response->getHeader('Set-Cookie');
        echo($cookie_str);
        file_put_contents('cookie.log',$cookie_str);

        $cookie_obj = new Cookie($cookie_str);
        $cookie_arr = $cookie_obj->toArray();
        print_r($cookie_arr);
    }
}